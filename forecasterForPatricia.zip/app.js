console.log("This is working!");
function attachEvents() {
    
    let weatherBtn = document.getElementById("submit");
    let symbol;

    weatherBtn.addEventListener("click", async function() {
        var requestOptions = {
        method: 'GET',
        redirect: 'follow'
    };
    let locationField = document.getElementById("location").value;
    let forcast = document.getElementById("forecast").style.display = "block";

    //THIS IS THE TOP, SINGLE WEATHER RESULT
    fetch("https://judgetests.firebaseio.com/locations.json", requestOptions)
        .then(response => response.json())
        .then(result => {
            // console.log(result)
            for(let report in result){
                if(result[report].code == locationField){
                    let code = result[report].code;
                    // let url = `https://judgetests.firebaseio.com/forecast/today/${code}.json`;
                    console.log("match");
                    fetch(`https://judgetests.firebaseio.com/forecast/today/${code}.json`)
                        .then(response => response.json())
                        .then(result => {
                            
                            for(let forecastInfo in result){
                                
                                if(result.forecast.condition == "Sunny"){
                                    symbol = '&#x2600'; // ☀
                                }else if(result.forecast.condition == "Partly sunny"){
                                    symbol = '&#x26C5'; // ⛅
                                }else if(result.forecast.condition == "Overcast"){
                                    symbol = '&#x2601'; // ☁
                                }else if(result.forecast.condition == "Rain"){
                                    symbol = '&#x2614'; // ☂
                                }
                                // console.log(result);
                                // console.log("this is the 1st symbol",symbol);
                            }
                            let degreesSymbol = '&#176'; // °
                            let current = document.getElementById("current");
                            let currentForecast = document.createElement("div");
                            currentForecast.innerHTML = `
                            <span class="condtion symbol">${symbol}</span>
                            <span class="condition">
                            <span class="forecast-data">${result.name}</span>
                            <span class="forecast-data">${result.forecast.low}${degreesSymbol}/${result.forecast.high}${degreesSymbol}</span>
                            <span class="forecast-data">${result.forecast.condition}</span>
                            </span>`;
                            current.appendChild(currentForecast);
                            // console.log(result[report].name);
                            
                        });

                        //this is for the bottom row - 3 day forecast...
                        fetch(`https://judgetests.firebaseio.com/forecast/upcoming/${code}.json`)
                        .then(response => response.json())
                        .then(result => {
                            
                            let resultArr = Object.entries(result);
                            let days = resultArr[0][1];

                            let upcoming = document.getElementById("upcoming")
                            
                            let forecastInfoDiv = document.createElement("div");
                            forecastInfoDiv.className = "forecast-info";
                            upcoming.appendChild(forecastInfoDiv);


                            // console.log(forecastInfoDiv);
                            let spanDiv = document.createElement("span");
                            spanDiv.className = "upcoming";
                            forecastInfoDiv.appendChild(spanDiv);

                            let str = "";
                            for(let day in days){

                                let forecastCond = days[day].condition;

                                switch(forecastCond){
                                    case "Sunny":
                                        symbol = '&#x2600';
                                    break;
                                    case "Partly sunny":
                                        symbol = '&#x26C5';
                                    break;
                                    case "Overcast":
                                        symbol = '&#x2601';
                                    break;
                                    case "Rain":
                                        symbol = '&#x2614';
                                    break;
                               }
                            
                            let degreesSymbol = '&#176'; // °
                            str += `<span class="symbol">${symbol}</span>                            
                            <span class="forecast-data">${days[day].low}${degreesSymbol}/${days[day].high}${degreesSymbol}</span>
                            <span class="forecast-data">${days[day].condition}</span>`;
                            console.log(str);
                            }
                            spanDiv.innerHTML = str;
                        })
                        .catch(error => console.log('Error', error));
                }             
            }
        });
    });
}
attachEvents(); 